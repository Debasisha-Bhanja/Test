Java Class support for Beyond Compare 2
Version 1.0, released 18-Dec-2003
by Scooter Software


Abstract
--------

These rules are an add-on to Beyond Compare that allows read-only
comparisons of Java's compiled class files (.class).  Associated files are
decompiled using the Jad java decompiler and saved as a textual source file.

This affects both the visual comparison and the folder viewer's rules-based
content comparison.  Non-text information may not be compared.


Installation
------------

1) Extract all files in JavaClass.zip into your Beyond Compare installation
   directory.  By default, this would be:
     C:\Program Files\Beyond Compare 2

2) Run Beyond Compare and from the "Tools" menu select "Import Settings...".

3) In "Select import file", enter the name of the rules file:
     C:\Program Files\Beyond Compare 2\JavaClass.xml

   Click "Next".  In the "Pick rules to import" list, "Java Class" should
   be checked.  Click "Next" again, then click "Finish" to import the rules.

4) Whenever you load a pair of CLASS files in the file viewer Beyond Compare
   will now display a comparison of the decompiled source.


Requirements
------------

Beyond Compare 2.1 or higher
Jad 1.5.8 (included)
  http://kpdus.tripod.com/jad.html


History
-------

 12/18/03  v1.0
          Official release.


To Contact Us
-------------

If you have any questions, comments or suggestions, contact
support at:

	Scooter Software
	2828 Marshall Court, #112
	Madison, WI  53705-2276

	web site:  http://www.scootersoftware.com/
	email:     support@scootersoftware.com
