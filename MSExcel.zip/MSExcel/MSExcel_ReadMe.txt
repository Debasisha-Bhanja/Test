Microsoft Excel support for Beyond Compare 2
Version 1.0.3, released 11-Jan-2008
MS Excel Rule by Scooter Software
MS Excel Formula Rule by Don Hjelle, Cross H�ller


Abstract
--------

These rules are an add-on to Beyond Compare that allows read-only
comparisons of Microsoft Excel workbooks (.xls,.xlsx).  Associated files are
loaded directly into Excel and then the contents are extracted as a 
comma-separated text file.  Your install of Excel must be patched or updated
to support .xlsx if that is not a native format.  The rules include an 
MS Excel rule (default) to display data in cells, and an MS Excel Formula 
rule to display formulas in cells.

This affects both the visual comparison and the folder viewer's rules-based
content comparison.  Non-text information will not be compared.


Installation
------------

1) Extract all files in MSExcel.zip into your Beyond Compare installation
   directory.  By default, this would be:
     C:\Program Files\Beyond Compare 2

2) Run Beyond Compare and from the "Tools" menu select "Import Settings...".

3) In "Select import file", enter the name of the rules file:
     C:\Program Files\Beyond Compare 2\MSExcel\MSExcel.xml

   Click "Next".  In the "Pick rules to import" list, "MS Excel" and 
   "MS Excel Formulas" should be checked.  Click "Next" again, then 
   click "Finish" to import the rules.

4) Whenever you load a pair of XLS files in the file viewer Beyond Compare
   will now display a comparison of the text.

5) To compare formulas in cells, select Tools|Pick Rules|MS Excel Formulas.


Requirements
------------

Beyond Compare 2.1 or higher
Microsoft Excel 97 or higher
Windows Scripting Host

.XLSX Support requires either:
Microsoft Excel 2007 or
Microsoft Office Compatibility Pack for Word, Excel, and PowerPoint 2007 File Formats


History
-------
 01/11/08  v1.0.3
		  Added Office 2007 extensions.
		  
 08/10/06  v1.0.2
          MS Excel Formula comparison rule.

 06/21/04  v1.0.1
          Support multiple sheets, separated by blank lines.

 05/26/04  v1.0
          Official release.


To Contact Us
-------------

If you have any questions, comments or suggestions, contact
support at:

	Scooter Software
	2828 Marshall Court, #112
	Madison, WI  53705-2276

	web site:  http://www.scootersoftware.com/
	email:     support@scootersoftware.com
